var dir_ab07916c289a4fc9c8e7bf628444de9a =
[
    [ "netcoreapp3.0", "dir_1953bbf8cba96b65618fcdf455769e72.html", "dir_1953bbf8cba96b65618fcdf455769e72" ]
];