var interface_space_invaders_1_1_i_game_object =
[
    [ "Start", "interface_space_invaders_1_1_i_game_object.html#a0a024241cc1433490449912accf573c5", null ],
    [ "Update", "interface_space_invaders_1_1_i_game_object.html#a782b8e2f4b5a23200f4e4ce6ce3e98fb", null ]
];