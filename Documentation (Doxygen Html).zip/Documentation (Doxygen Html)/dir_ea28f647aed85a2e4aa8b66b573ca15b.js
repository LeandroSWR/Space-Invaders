var dir_ea28f647aed85a2e4aa8b66b573ca15b =
[
    [ "netcoreapp3.0", "dir_b92bea50386d32dac425a6808f85fbfe.html", "dir_b92bea50386d32dac425a6808f85fbfe" ]
];