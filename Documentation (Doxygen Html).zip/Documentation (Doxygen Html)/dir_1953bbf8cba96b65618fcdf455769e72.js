var dir_1953bbf8cba96b65618fcdf455769e72 =
[
    [ "SpaceInvaders.AssemblyInfo.cs", "_debug_2netcoreapp3_80_2_space_invaders_8_assembly_info_8cs.html", null ]
];