var dir_b92bea50386d32dac425a6808f85fbfe =
[
    [ "SpaceInvaders.AssemblyInfo.cs", "_release_2netcoreapp3_80_2_space_invaders_8_assembly_info_8cs.html", null ]
];