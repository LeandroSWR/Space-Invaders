var searchData=
[
  ['this_5bint_20x_2c_20int_20y_5d_260',['this[int x, int y]',['../class_space_invaders_1_1_double_buffer2_d.html#ab10e5874744301fbfebe483bf8e13f05',1,'SpaceInvaders::DoubleBuffer2D']]]
];
