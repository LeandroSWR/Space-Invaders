var searchData=
[
  ['ship_141',['Ship',['../class_space_invaders_1_1_ship.html',1,'SpaceInvaders']]],
  ['sprites_142',['Sprites',['../class_space_invaders_1_1_sprites.html',1,'SpaceInvaders']]]
];
