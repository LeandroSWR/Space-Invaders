var searchData=
[
  ['firstsprite_252',['FirstSprite',['../class_space_invaders_1_1_enemy.html#a19eeb256b11992922fa03c7ff86e641b',1,'SpaceInvaders::Enemy']]]
];
