var searchData=
[
  ['increasey_253',['IncreaseY',['../class_space_invaders_1_1_enemy.html#a7e87c3cb3c18951380f2d1573619d2a6',1,'SpaceInvaders::Enemy']]]
];
