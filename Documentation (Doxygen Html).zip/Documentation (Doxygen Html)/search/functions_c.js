var searchData=
[
  ['rendermenu_205',['RenderMenu',['../class_space_invaders_1_1_menu.html#a9588fc74f9dcc0a1b96e62271001e18a',1,'SpaceInvaders::Menu']]],
  ['resetmoveup_206',['ResetMoveUp',['../class_space_invaders_1_1_enemies.html#a8af4e52c9cfec13f2e43cf09f0ec67a7',1,'SpaceInvaders::Enemies']]]
];
