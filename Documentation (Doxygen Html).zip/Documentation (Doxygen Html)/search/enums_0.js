var searchData=
[
  ['enemytype_235',['EnemyType',['../namespace_space_invaders.html#a64b3f7632e1258203e76be4e5961baaf',1,'SpaceInvaders']]],
  ['explosiontype_236',['ExplosionType',['../namespace_space_invaders.html#a85ac4045b32407de8353a8cec901be43',1,'SpaceInvaders']]]
];
