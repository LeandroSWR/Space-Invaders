var searchData=
[
  ['ydim_234',['YDim',['../class_space_invaders_1_1_double_buffer2_d.html#aacb061018a00300a51b85de3edb41f25',1,'SpaceInvaders::DoubleBuffer2D']]]
];
