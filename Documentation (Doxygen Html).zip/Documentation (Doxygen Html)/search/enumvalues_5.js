var searchData=
[
  ['small_244',['SMALL',['../namespace_space_invaders.html#a85ac4045b32407de8353a8cec901be43a9b9c17e13f0e3dc9860a26e08b59b2a7',1,'SpaceInvaders']]]
];
