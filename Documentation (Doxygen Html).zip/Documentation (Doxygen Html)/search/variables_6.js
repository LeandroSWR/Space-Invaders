var searchData=
[
  ['xdim_233',['XDim',['../class_space_invaders_1_1_double_buffer2_d.html#a96873ffa7d903bc757616d437a0c6e0f',1,'SpaceInvaders::DoubleBuffer2D']]]
];
