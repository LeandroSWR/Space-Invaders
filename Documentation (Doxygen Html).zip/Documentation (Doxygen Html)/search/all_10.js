var searchData=
[
  ['selectionstring_92',['selectionString',['../class_space_invaders_1_1_sprites.html#a5d1b884606d3bbf294b2258cc61e299f',1,'SpaceInvaders::Sprites']]],
  ['setcolor_93',['SetColor',['../class_space_invaders_1_1_barrier.html#a3c5b11cd91f6c7d416449ef3dee4ebfa',1,'SpaceInvaders::Barrier']]],
  ['setdestroyed_94',['SetDestroyed',['../class_space_invaders_1_1_barrier.html#a329ef179b34be7c2d2968f526b8f101b',1,'SpaceInvaders::Barrier']]],
  ['ship_95',['Ship',['../class_space_invaders_1_1_ship.html',1,'SpaceInvaders.Ship'],['../class_space_invaders_1_1_ship.html#ad13ce871da4de6ab75d6dbdc91bd7ccf',1,'SpaceInvaders.Ship.Ship()']]],
  ['ship_2ecs_96',['Ship.cs',['../_ship_8cs.html',1,'']]],
  ['shipbullets_97',['ShipBullets',['../class_space_invaders_1_1_ship.html#ab134b7525be9c0e6ed6bb133dae78427',1,'SpaceInvaders::Ship']]],
  ['shipdestroyed_98',['shipDestroyed',['../class_space_invaders_1_1_enemies.html#a553ead5d425e585e305801ff0ca63f09',1,'SpaceInvaders::Enemies']]],
  ['small_99',['SMALL',['../namespace_space_invaders.html#a85ac4045b32407de8353a8cec901be43a9b9c17e13f0e3dc9860a26e08b59b2a7',1,'SpaceInvaders']]],
  ['spaceinvaders_100',['SpaceInvaders',['../namespace_space_invaders.html',1,'']]],
  ['spaceinvaders_2eassemblyinfo_2ecs_101',['SpaceInvaders.AssemblyInfo.cs',['../_debug_2netcoreapp3_80_2_space_invaders_8_assembly_info_8cs.html',1,'(Global Namespace)'],['../_release_2netcoreapp3_80_2_space_invaders_8_assembly_info_8cs.html',1,'(Global Namespace)']]],
  ['spacestring_102',['spaceString',['../class_space_invaders_1_1_sprites.html#a375937a9fea28eba49a6ff059750d367',1,'SpaceInvaders::Sprites']]],
  ['sprites_103',['Sprites',['../class_space_invaders_1_1_sprites.html',1,'SpaceInvaders']]],
  ['sprites_2ecs_104',['Sprites.cs',['../_sprites_8cs.html',1,'']]],
  ['start_105',['Start',['../class_space_invaders_1_1_barriers.html#ad9ef53820da68e6d934e65097d4d61d1',1,'SpaceInvaders.Barriers.Start()'],['../class_space_invaders_1_1_game_object.html#a9e0693c32f7cfccab37f4391912de276',1,'SpaceInvaders.GameObject.Start()'],['../interface_space_invaders_1_1_i_game_object.html#a0a024241cc1433490449912accf573c5',1,'SpaceInvaders.IGameObject.Start()']]],
  ['swap_106',['Swap',['../class_space_invaders_1_1_double_buffer2_d.html#a32d8e4c959aefff6414a4f5f3a16352d',1,'SpaceInvaders::DoubleBuffer2D']]]
];
