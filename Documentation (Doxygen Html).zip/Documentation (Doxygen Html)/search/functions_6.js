var searchData=
[
  ['game_193',['Game',['../class_space_invaders_1_1_game.html#ad89c0fdf2943bffc5006a3d7239df7e0',1,'SpaceInvaders::Game']]]
];
