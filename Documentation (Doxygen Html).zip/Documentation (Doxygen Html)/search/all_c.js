var searchData=
[
  ['one_78',['ONE',['../namespace_space_invaders.html#a64b3f7632e1258203e76be4e5961baafabc21e6484530fc9d0313cb816b733396',1,'SpaceInvaders']]],
  ['ovni_79',['Ovni',['../class_space_invaders_1_1_ovni.html',1,'SpaceInvaders.Ovni'],['../class_space_invaders_1_1_ovni.html#aa8bb4182edacc361abf11eadeb2c6e19',1,'SpaceInvaders.Ovni.Ovni()']]],
  ['ovni_2ecs_80',['Ovni.cs',['../_ovni_8cs.html',1,'']]]
];
