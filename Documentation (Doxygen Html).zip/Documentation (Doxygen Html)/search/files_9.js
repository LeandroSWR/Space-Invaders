var searchData=
[
  ['ship_2ecs_168',['Ship.cs',['../_ship_8cs.html',1,'']]],
  ['spaceinvaders_2eassemblyinfo_2ecs_169',['SpaceInvaders.AssemblyInfo.cs',['../_debug_2netcoreapp3_80_2_space_invaders_8_assembly_info_8cs.html',1,'(Global Namespace)'],['../_release_2netcoreapp3_80_2_space_invaders_8_assembly_info_8cs.html',1,'(Global Namespace)']]],
  ['sprites_2ecs_170',['Sprites.cs',['../_sprites_8cs.html',1,'']]]
];
