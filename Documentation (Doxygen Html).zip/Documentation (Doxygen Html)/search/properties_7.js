var searchData=
[
  ['pixelchar_257',['pixelChar',['../struct_space_invaders_1_1_pixel.html#a657efaa95fdb383a87329136e156f658',1,'SpaceInvaders::Pixel']]],
  ['pixelcolor_258',['pixelColor',['../struct_space_invaders_1_1_pixel.html#a1a1cd775ef9610484f5f3d7cf81a88d1',1,'SpaceInvaders::Pixel']]]
];
