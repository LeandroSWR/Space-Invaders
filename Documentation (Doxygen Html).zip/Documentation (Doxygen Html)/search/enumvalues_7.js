var searchData=
[
  ['up_247',['UP',['../namespace_space_invaders.html#a5bb93bd92cec33622a9ea43134011c60afbaedde498cdead4f2780217646e9ba1',1,'SpaceInvaders']]]
];
