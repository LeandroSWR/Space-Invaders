var class_space_invaders_1_1_enemy =
[
    [ "Enemy", "class_space_invaders_1_1_enemy.html#a163337c79430738423db7e732c8372a9", null ],
    [ "DecreaseY", "class_space_invaders_1_1_enemy.html#a9bdae3c18f1b5906cb981f026cc59255", null ],
    [ "Delete", "class_space_invaders_1_1_enemy.html#a90b07cafc8037afb3d513d6b2219c3cd", null ],
    [ "Update", "class_space_invaders_1_1_enemy.html#a310e88e2ad59bbef3c01f9029fa75460", null ],
    [ "YIncreasse", "class_space_invaders_1_1_enemy.html#a0b1ea9921aef9fb33659bb696cd5880e", null ],
    [ "Coordinates", "class_space_invaders_1_1_enemy.html#ab46b6dd8b56dd3ff8d5ef251bed6d2bd", null ],
    [ "CanMove", "class_space_invaders_1_1_enemy.html#ad765e6aac0c1a76f3d91206472829583", null ],
    [ "FirstSprite", "class_space_invaders_1_1_enemy.html#a19eeb256b11992922fa03c7ff86e641b", null ],
    [ "IncreaseY", "class_space_invaders_1_1_enemy.html#a7e87c3cb3c18951380f2d1573619d2a6", null ],
    [ "MovementType", "class_space_invaders_1_1_enemy.html#aaa09c38664534aab446755f698d258a9", null ]
];