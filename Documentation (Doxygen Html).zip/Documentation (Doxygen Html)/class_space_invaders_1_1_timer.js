var class_space_invaders_1_1_timer =
[
    [ "Timer", "class_space_invaders_1_1_timer.html#af8cc1bb3a1d71939cd5854c28d3ee915", null ],
    [ "IsCounting", "class_space_invaders_1_1_timer.html#a1abb09e317b0f200916855a0f1f3f56c", null ]
];