var struct_space_invaders_1_1_pixel =
[
    [ "pixelChar", "struct_space_invaders_1_1_pixel.html#a657efaa95fdb383a87329136e156f658", null ],
    [ "pixelColor", "struct_space_invaders_1_1_pixel.html#a1a1cd775ef9610484f5f3d7cf81a88d1", null ]
];