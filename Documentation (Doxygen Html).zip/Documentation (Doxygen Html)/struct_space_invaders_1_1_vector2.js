var struct_space_invaders_1_1_vector2 =
[
    [ "Vector2", "struct_space_invaders_1_1_vector2.html#ad823382c875e4d66020c3912f041a9b2", null ],
    [ "X", "struct_space_invaders_1_1_vector2.html#a4e429ff5a7536288219b89ee2c8a8ec7", null ],
    [ "Y", "struct_space_invaders_1_1_vector2.html#a9df206709eec15d13465977c69ca373b", null ]
];