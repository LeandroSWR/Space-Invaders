var class_space_invaders_1_1_game_object =
[
    [ "Start", "class_space_invaders_1_1_game_object.html#a9e0693c32f7cfccab37f4391912de276", null ],
    [ "Update", "class_space_invaders_1_1_game_object.html#a633ca7f4982eedaadab0171e4746233b", null ]
];