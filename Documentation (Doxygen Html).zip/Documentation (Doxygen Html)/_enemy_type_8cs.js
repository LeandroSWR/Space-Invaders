var _enemy_type_8cs =
[
    [ "EnemyType", "_enemy_type_8cs.html#a64b3f7632e1258203e76be4e5961baaf", [
      [ "ONE", "_enemy_type_8cs.html#a64b3f7632e1258203e76be4e5961baafabc21e6484530fc9d0313cb816b733396", null ],
      [ "TWO", "_enemy_type_8cs.html#a64b3f7632e1258203e76be4e5961baafa0f82d86afa0f5dc965c5c15aca58dcfb", null ],
      [ "THREE", "_enemy_type_8cs.html#a64b3f7632e1258203e76be4e5961baafa413af0de1f97a2155acf2b8b26ab36e2", null ]
    ] ]
];